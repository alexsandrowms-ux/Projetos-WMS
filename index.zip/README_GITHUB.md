# Gestão de Produto WMS — publicação no GitHub Pages

1. Crie um repositório GitHub, preferencialmente privado para o código. Confirme se seu plano permite Pages privado e controle de acesso; **GitHub Pages não é, por si só, um sistema de autenticação**.
2. Faça upload de `index.html` na raiz do repositório.
3. Em **Settings → Pages**, configure **Deploy from a branch**, branch `main` e pasta `/(root)`.
4. Acesse o endereço de Pages fornecido pelo GitHub após a publicação.

## Atenção: armazenamento

Os cadastros são gravados em `localStorage`, apenas no navegador e domínio usados. **GitHub Pages hospeda o site, não os dados:** alterações no notebook não aparecerão automaticamente no celular. Para transferir dados, use Backup JSON/Importar JSON.

Para sincronização segura entre dispositivos, implemente posteriormente autenticação e banco de dados (por exemplo Supabase com RLS), mantendo credenciais privilegiadas **fora** do HTML. Dados de clientes, incidentes, demandas internas e chamados não devem ser publicados em repositório aberto sem autorização.

## Arquivos

- `index.html`: aplicação pronta para Pages; funciona sem build.
- `gestao_produto_wms.html`: cópia equivalente.
